#include "../../GameEngine/include/GameEngine.h"
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <ncurses.h>
#include <thread>
#include <unistd.h>

// Constant paramters
constexpr int SCREEN_WIDTH = 80;
constexpr int SCREEN_HEIGHT = 24;
constexpr int FRAME_RATE = 60;
constexpr int UI_LAYER = 100;

// Variable parameters
using Clock = std::chrono::steady_clock;
bool exitFlag = false;

std::string GAME_STATE = "START";

// Button Functions
void quitApp() { exitFlag = true; }
void temp() {}

int main() {
  // ----------------------------------------------------------------------------------------------------------------------------------------

  // Main Menu UI Entities
  auto counterEntity = loadEntity("counter", true, 0, true);

  Camera gameCamera = Camera(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);

  // ----------------------------------------------------------------------------------------------------------------------------------------

  // Initial Displace
  int midX = (SCREEN_WIDTH / 2);
  int midY = (SCREEN_HEIGHT / 2);
  counterEntity->displace(midX, midY);

  // Initialization
  int userInput = 0;
  constexpr float FRAME_DURATION = 1.0f / FRAME_RATE;
  auto lastTime = Clock::now();
  MEVENT event;
  bool drawing = false;
  int lastMouseX = -1;
  int lastMouseY = -1;
  Display::initCurse();

  // GameLoop
  while (userInput != '`' && !exitFlag) {
    // --- INPUT HANDLING ---
    int ch;
    while ((ch = getch()) !=
           ERR) { // non-blocking, get all input events this frame
      userInput = ch;

      // Mouse Handling
      // --------------
      if (ch == KEY_MOUSE) {
        if (getmouse(&event) == OK) {

          // Camera Drag
          if (event.bstate & BUTTON2_PRESSED) {
            drawing = true;
            lastMouseX = event.x;
            lastMouseY = event.y;
          }

          if (event.bstate & BUTTON2_RELEASED) {
            drawing = false;
            lastMouseX = -1;
            lastMouseY = -1;
          }

          if (drawing && (event.bstate & REPORT_MOUSE_POSITION)) {
            // Calculate how much the mouse moved
            int dx = lastMouseX - event.x;
            int dy = lastMouseY - event.y;

            // Pan the camera accordingly
            gameCamera.displaceViewPort(-dx, -dy);

            // Update the last known position
            lastMouseX = event.x;
            lastMouseY = event.y;
          }
        }
      }
      // Keyboard Handling
      // -----------------

      // Player Movement Test
      else if (ch == 'w') {
        counterEntity->displace(0, -2);
      } else if (ch == 'a') {
        counterEntity->displace(-2, 0);
      } else if (ch == 's') {
        counterEntity->displace(0, 2);
      } else if (ch == 'd') {
        counterEntity->displace(2, 0);
      }

      // Camera Movement Test
      else if (ch == 'i') {
        gameCamera.displaceViewPort(0, -2);
      } else if (ch == 'k') {
        gameCamera.displaceViewPort(0, 2);
      } else if (ch == 'j') {
        gameCamera.displaceViewPort(-2, 0);
      } else if (ch == 'l') {
        gameCamera.displaceViewPort(2, 0);
      }
    }

    // --- FRAME UPDATES (LIMITED TO 60FPS) ---
    auto currentTime = Clock::now();
    std::chrono::duration<float> delta = currentTime - lastTime;
    if (delta.count() >= FRAME_DURATION) {

      Display::updateAllEntities(delta.count());
      Display::refreshCurse();

      lastTime = currentTime;
    }

    // --- Tiny sleep to prevent CPU overuse ---
    std::this_thread::sleep_for(std::chrono::milliseconds(1));
  }

  Display::closeCurseWindow();
  return 0;
}
