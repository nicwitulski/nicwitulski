#include "Display.h"
#include <ncurses.h>

void Display::initCurse() {
  initscr();             // Start curses mode
  noecho();              // Don't echo keypresses
  cbreak();              // Disable line buffering
  keypad(stdscr, TRUE);  // Enable function keys and arrow keys
  nodelay(stdscr, TRUE); // Non-blocking getch
  mousemask(ALL_MOUSE_EVENTS | REPORT_MOUSE_POSITION,
            NULL);  // Enable mouse events
  mouseinterval(0); // No delay for mouse clicks
  curs_set(0);

  printf("\033[?1003h\n"); // Enable mouse tracking in xterm
};

char Display::getUserInput() { return getch(); }

void Display::closeCurseWindow() {
  printf("\033[?1003l\n"); // Disable mouse tracking
  endwin();
};

void Display::refreshCurse() { refresh(); }

void Display::printPixel(Pixel pixel) {
  mvprintw(pixel.getPosition().getY(), pixel.getPosition().getX(), "%c",
           pixel.getCharacter());
};

void Display::printSprite(Sprite sprite) {
  for (int i = 0; i < sprite.getPixels().size(); i++) {
    Pixel pixel = sprite.getPixels().at(i);
    printPixel(pixel);
  }
};

void Display::eraseSprite(Sprite sprite) {
  for (int i = 0; i < sprite.getPixels().size(); i++) {
    Pixel pixel = sprite.getPixels().at(i);
    printPixel(Pixel(
        Position(pixel.getPosition().getX(), pixel.getPosition().getY()), ' '));
  }
}

void Display::updateAnimation(float deltaTime, Animation &animation) {
  animation.update(deltaTime);
  eraseSprite(animation.getPreviousFrameSprite());
  printSprite(animation.getCurrentFrameSprite());
}

void Display::updateAllEntities(float deltaTime) {
  for (auto &entity : allEntities) {
    if (entity->didMove()) {
      eraseSprite(entity->getSpriteBeforeMove());
      entity->setMoved(false);
    }
    for (Animation &animation : entity->getAnimations()) {
      if (animation.getAnimationName() == entity->getCurrentAnimationName()) {
        updateAnimation(deltaTime, animation);
      }
    }
  }
}