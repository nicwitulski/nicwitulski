#ifndef DISPLAY_H
#define DISPLAY_H

#include "../Core/Base/Animation.h"
#include "../Parameters/Parameters.h"
#include "ncurses.h"
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <vector>

class Display {
public:
  static void initCurse();
  static char getUserInput();
  static void closeCurseWindow();
  static void refreshCurse();
  static void refreshAllEntities(float deltaTime);
  static void printPixel(Pixel pixel);
  static void printSprite(Sprite sprite);
  static void eraseSprite(Sprite sprite);
  static void updateAnimation(float deltaTime, Animation &animation);
  static void updateAllEntities(float deltaTime);
};

#endif