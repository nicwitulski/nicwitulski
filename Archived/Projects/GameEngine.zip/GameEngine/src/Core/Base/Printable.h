#ifndef PRINTABLE_H
#define PRINTABLE_H

#include "Animation.h"
#include <string>
#include <vector>

class Printable {
protected:
  std::vector<Animation> m_animations;
  std::string m_currentAnimation = "default";
  bool m_moved = false;
  Position m_anchor;
  bool m_visable;
  int m_layer;
  bool m_moveableByCamera;
  Sprite m_spriteBeforeMove;

public:
  virtual void addAnimation(const Animation animation);
  virtual bool setCurrentAnimation(const std::string name);
  virtual std::vector<Animation> &getAnimations();
  virtual std::string getCurrentAnimationName();
  virtual Position getAnchor();
  virtual void displace(int dx, int dy);
  virtual void moveToPosition(Position position);
  virtual bool isVisable();
  virtual int getLayer();
  virtual void setVisability(bool visable);
  virtual void setLayer(int layer);
  virtual bool isMoveableByCamera();
  virtual void setMoveableByCamera(bool moveable);
  virtual bool didMove();
  virtual void setMoved(bool moved);
  virtual Sprite getSpriteBeforeMove();

  virtual ~Printable() = default;
};

#endif