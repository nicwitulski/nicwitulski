#ifndef CAMERA_H
#define CAMERA_H

#include "../../Parameters/Parameters.h"
#include <cstdint>

class Camera {
private:
  int m_xOffset;
  int m_yOffset;
  int m_viewPortMaxX;
  int m_viewPortMaxY;

public:
  Camera();
  Camera(int xOffset, int yOffset, int viewPortMaxX, int viewPortMaxY);
  void displaceViewPort(int dx, int dy);
};

#endif