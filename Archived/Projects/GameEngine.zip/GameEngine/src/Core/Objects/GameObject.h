#ifndef GAMEOBJECT_H
#define GAMEOBJECT_H

#include "../Base/Printable.h"

class GameObject : public Printable {
protected:
public:
  GameObject();
  GameObject(bool visable, int layer, bool moveableByCamera,
             std::vector<Animation> animations, std::string currentAnimation);
};

#endif