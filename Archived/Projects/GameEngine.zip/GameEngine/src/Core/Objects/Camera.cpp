#include "Camera.h"

Camera::Camera() {
  m_xOffset = 0;
  m_yOffset = 0;
  m_viewPortMaxX = 80;
  m_viewPortMaxY = 24;
};

Camera::Camera(int topLeftX, int topLeftY, int viewPortMaxX, int viewPortMaxY) {
  m_viewPortMaxX = viewPortMaxX;
  m_viewPortMaxY = viewPortMaxY;
  m_xOffset = topLeftX;
  m_yOffset = topLeftY;
};

void Camera::displaceViewPort(int dx, int dy) {
  int oldX = m_xOffset;
  int oldY = m_yOffset;

  m_xOffset += dx;
  m_yOffset += dy;

  int deltaX = m_xOffset - oldX;
  int deltaY = m_yOffset - oldY;

  for (auto &entity : allEntities) {
    if (entity->isMoveableByCamera()) {
      entity->displace(deltaX, deltaY);
    }
  }
};