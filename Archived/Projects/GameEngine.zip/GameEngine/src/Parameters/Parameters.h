#ifndef PARAMETERS_H
#define PARAMETERS_H

#pragma once
#include "../Core/Objects/Entity.h"
#include <memory>
#include <vector>

static std::vector<std::shared_ptr<Entity>> allEntities;

#endif
