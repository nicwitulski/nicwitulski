#include "Display.h"
#include <algorithm>
#include <ncurses.h>

void initCurse() {
  initscr();
  raw();
  noecho();
  cbreak();
  keypad(stdscr, TRUE);
  timeout(0);
  curs_set(0);
  mousemask(ALL_MOUSE_EVENTS | REPORT_MOUSE_POSITION, nullptr);
  curs_set(0);
}

char getUserInput() { return getch(); }

void closeCurseWindow() { endwin(); }

void refreshCurse() { refresh(); }

void refreshAllEntities(std::vector<Entity *> refreshedEntities,
                        float deltaTime) {
  std::sort(refreshedEntities.begin(), refreshedEntities.end(),
            [](Entity *a, Entity *b) { return a->getLayer() < b->getLayer(); });

  for (auto &entity : refreshedEntities) {
    entity->refresh(deltaTime);
  }
}