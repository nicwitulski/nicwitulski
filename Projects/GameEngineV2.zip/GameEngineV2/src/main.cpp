#include "Controller/SpriteUtils.h"
#include "Model/Entity.h"
#include "View/Display.h"
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <ncurses.h>
#include <thread>
#include <unistd.h>

// Constant paramters
constexpr uint8_t SCREEN_WIDTH = 80;
constexpr uint8_t SCREEN_HEIGHT = 24;
constexpr uint8_t FRAME_RATE = 60;
using Clock = std::chrono::steady_clock;

int main() {
  char userInput = ' ';
  constexpr float FRAME_DURATION = 1.0f / FRAME_RATE;
  auto lastTime = Clock::now();

  std::vector<Animation> playerAnimations;
  Animation playerIdleAnimation = loadAnimation("player", "idle", true);
  playerAnimations.push_back(playerIdleAnimation);
  Entity player = Entity("player", playerAnimations, true, 0);

  std::vector<Animation> testAnimations;
  Animation counterAnimation = loadAnimation("test", "count", true);
  testAnimations.push_back(counterAnimation);
  Entity test = Entity("test", testAnimations, true, 1);

  int midX = (SCREEN_WIDTH / 2);
  int midY = (SCREEN_HEIGHT / 2);
  test.displace(midX, midY);

  // GameLoop
  initCurse();
  MEVENT event;
  while (userInput != '`') {
    // FPS Logic
    auto currentTime = Clock::now();
    std::chrono::duration<float> deltaTime = currentTime - lastTime;
    lastTime = currentTime;

    // User Input
    userInput = getUserInput();
    int intagerInput = (int)userInput;

    // Game Logic
    // ------------------------------------------------------------------------------------------------------
    // Process user input:
    if (userInput != ERR) {
      if (intagerInput == KEY_MOUSE) {
        if (getmouse(&event) == OK) {
          if (event.bstate & BUTTON1_PRESSED) {
            mvaddch(event.y, event.x, 'X');
          }
        }
      }
      if (userInput == 'w') {
        player.displace(0, -5);
      } else if (userInput == 'a') {
        player.displace(-5, 0);
      } else if (userInput == 's') {
        // player.displace(0, 5);
        player.displace(0, 5);
      } else if (userInput == 'd') {
        player.displace(5, 0);
      }
    }

    std::vector<Entity *> refreshedEntities;
    refreshedEntities.push_back(&test);
    refreshedEntities.push_back(&player);

    refreshAllEntities(refreshedEntities, deltaTime.count());
    refresh();
    // ------------------------------------------------------------------------------------------------------

    // FPS Logic: Sleep to limit to target frame rate
    auto frameEnd = Clock::now();
    std::chrono::duration<float> frameTime = frameEnd - currentTime;
    if (frameTime.count() < FRAME_DURATION) {
      std::this_thread::sleep_for(
          std::chrono::duration<float>(FRAME_DURATION - frameTime.count()));
    }
  }

  closeCurseWindow();
  return 0;
}
