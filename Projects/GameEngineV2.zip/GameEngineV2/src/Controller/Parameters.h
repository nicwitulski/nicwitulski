#pragma once
#include "../Model/Entity.h"
#include <memory>
#include <vector>

extern std::vector<std::shared_ptr<Entity>> allEntities;