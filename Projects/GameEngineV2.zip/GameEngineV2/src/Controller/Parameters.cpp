#include "Parameters.h"

std::vector<std::shared_ptr<Entity>> allEntities;