#include "Camera.h"
#include "../Controller/Parameters.h"

Camera::Camera() {
  m_xOffset = 0;
  m_yOffset = 0;
  m_viewPortMaxX = 80;
  m_viewPortMaxY = 24;
};

Camera::Camera(uint8_t topLeftX, uint8_t topLeftY, uint8_t viewPortMaxX,
               uint8_t viewPortMaxY) {
  m_viewPortMaxX = viewPortMaxX;
  m_viewPortMaxY = viewPortMaxY;
  m_xOffset = topLeftX;
  m_yOffset = topLeftY;
};

void Camera::displaceViewPort(uint8_t dx, uint8_t dy) {
  m_xOffset += dx;
  m_yOffset += dy;
  updateOffset();
}

void Camera::updateOffset() {
  for (auto &entity : allEntities) {
    entity->displace(m_xOffset, m_yOffset);
  }
}